#!/bin/sh
# Start the ssh server
/etc/init.d/ssh start
# Execute the CMD
exec "$@"

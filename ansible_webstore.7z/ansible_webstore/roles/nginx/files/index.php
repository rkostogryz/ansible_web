<html>
<body>
<h2> Output.</h2>
<?php
$db = pg_pconnect("host=172.17.0.4 port=5432 dbname=booktown user=postgres");
$result = pg_query($db,"SELECT * FROM books");
while ($row = pg_fetch_row($result))
{
echo $row[1]. '<br/>';
}

?>
<h2>server info</h2>
<?php
echo php_uname('n');
?>
</body>
</html>

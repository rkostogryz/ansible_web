Need to install environment tools:
1.  
# refreshing the repositories
sudo apt update
# its wise to keep the system up to date!
# you can skip the following line if you not
# want to update all your software
sudo apt upgrade
# installing python 2.7 and pip for it
sudo apt install python2.7 python-pip
# installing python-pip for 3.6
sudo apt install python3-pip
# add ansible repository
sudo apt-add-repository ppa:ansible/ansible.
# update apt
sudo apt-get update
# install Ansible 
sudo apt-get install ansible -y

2. pip install docker-compose


3. Run roles from dirrectory where you put content
   ansible-playbook run_roles.yml
 
